#!/bin/bash
# =============================================================
#   RWN Document Suite v6 — Iniciar servidor (manual)
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_PYTHON="$SCRIPT_DIR/venv/bin/python3"

if [ ! -f "$VENV_PYTHON" ]; then
    echo "[ERRO] Ambiente virtual não encontrado."
    echo "       Execute primeiro: sudo bash 1_instalar.sh"
    exit 1
fi

echo ""
echo "====================================================="
echo "  RWN Document Suite — Iniciando Servidor"
echo "====================================================="
echo ""
echo "Servidor rodando em: http://0.0.0.0:5000"
echo "Para acessar na rede use o IP do servidor na porta 5000"
echo ""
echo "Pressione CTRL+C para encerrar."
echo ""

cd "$SCRIPT_DIR"
exec "$VENV_PYTHON" app.py
