#!/bin/bash
# =============================================================
#   RWN Document Suite v6 — Instalar como serviço systemd
#   Equivalente ao 3_INSTALAR_SERVICO_WINDOWS.bat (NSSM)
# =============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

info() { echo -e "${BLUE}[INFO]${NC} $1"; }
ok()   { echo -e "${GREEN}[OK]${NC}   $1"; }
erro() { echo -e "${RED}[ERRO]${NC} $1"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVICE_NAME="rwn-document-suite"
VENV_PYTHON="$SCRIPT_DIR/venv/bin/python3"

if [ "$EUID" -ne 0 ]; then
    erro "Execute como root: sudo bash 3_instalar_servico.sh"
fi

if [ ! -f "$VENV_PYTHON" ]; then
    erro "Ambiente virtual não encontrado. Execute: sudo bash 1_instalar.sh"
fi

# Descobrir usuário dono dos arquivos
RUN_USER="${SUDO_USER:-$(stat -c '%U' "$SCRIPT_DIR/app.py")}"
[ "$RUN_USER" = "root" ] && RUN_USER="www-data"

echo ""
echo "====================================================="
echo "  RWN Document Suite — Instalar Serviço systemd"
echo "====================================================="
echo ""
info "Diretório da aplicação : $SCRIPT_DIR"
info "Usuário de execução    : $RUN_USER"
info "Python (venv)          : $VENV_PYTHON"
echo ""

# ── Criar arquivo de serviço systemd ───────────────────────
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"

info "Criando $SERVICE_FILE..."
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=RWN Document Suite - Compressor PDF / Conversor PDF→Word
After=network.target

[Service]
Type=simple
User=$RUN_USER
WorkingDirectory=$SCRIPT_DIR
ExecStart=$VENV_PYTHON $SCRIPT_DIR/app.py
Restart=always
RestartSec=5
StandardOutput=append:$SCRIPT_DIR/logs/service_out.log
StandardError=append:$SCRIPT_DIR/logs/service_err.log

# Limites de recursos
LimitNOFILE=65536
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
EOF

ok "Arquivo de serviço criado."

# ── Garantir pastas de log ──────────────────────────────────
mkdir -p "$SCRIPT_DIR/logs"
chown -R "$RUN_USER":"$RUN_USER" "$SCRIPT_DIR/logs" 2>/dev/null || true

# ── Recarregar e habilitar ──────────────────────────────────
info "Recarregando systemd daemon..."
systemctl daemon-reload

info "Parando serviço anterior (se existir)..."
systemctl stop "$SERVICE_NAME" 2>/dev/null || true

info "Habilitando serviço para iniciar com o sistema..."
systemctl enable "$SERVICE_NAME"

info "Iniciando serviço..."
systemctl start "$SERVICE_NAME"

sleep 2

if systemctl is-active --quiet "$SERVICE_NAME"; then
    ok "Serviço $SERVICE_NAME está ATIVO."
else
    echo ""
    echo "Status do serviço:"
    systemctl status "$SERVICE_NAME" --no-pager || true
    echo ""
    erro "Serviço não iniciou. Verifique os logs: journalctl -u $SERVICE_NAME -n 50"
fi

echo ""
echo "====================================================="
echo "  Serviço instalado e iniciado com sucesso!"
echo "====================================================="
echo ""
echo "Comandos úteis:"
echo "  Ver status  : sudo systemctl status $SERVICE_NAME"
echo "  Ver logs    : sudo journalctl -u $SERVICE_NAME -f"
echo "  Reiniciar   : sudo systemctl restart $SERVICE_NAME"
echo "  Parar       : sudo systemctl stop $SERVICE_NAME"
echo "  Desabilitar : sudo systemctl disable $SERVICE_NAME"
echo ""
echo "Acesse: http://$(hostname -I | awk '{print $1}'):5000"
echo ""
