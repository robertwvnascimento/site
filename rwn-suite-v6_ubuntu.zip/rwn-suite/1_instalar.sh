#!/bin/bash
# =============================================================
#   RWN Document Suite v6 — Instalação para Ubuntu Server
#   Autor: Robert William V. Nascimento
# =============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
ok()      { echo -e "${GREEN}[OK]${NC}   $1"; }
warn()    { echo -e "${YELLOW}[AVISO]${NC} $1"; }
erro()    { echo -e "${RED}[ERRO]${NC} $1"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "====================================================="
echo "  RWN Document Suite v6 - Instalação Ubuntu Server"
echo "====================================================="
echo ""

# ── Verificar root ─────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
    erro "Execute como root: sudo bash 1_instalar.sh"
fi

# ── Atualizar apt e instalar dependências de sistema ────────
info "Atualizando lista de pacotes..."
apt-get update -qq

info "Instalando Python 3, pip, venv e dependências de sistema..."
apt-get install -y -qq \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    build-essential \
    libpoppler-cpp-dev \
    poppler-utils \
    tesseract-ocr \
    tesseract-ocr-por \
    tesseract-ocr-eng \
    libgl1 \
    libglib2.0-0 \
    libsm6 \
    libxrender1 \
    libxext6 \
    libjpeg-dev \
    libpng-dev \
    zlib1g-dev \
    nginx \
    2>/dev/null
ok "Dependências de sistema instaladas."

# ── Criar ambiente virtual ──────────────────────────────────
VENV_DIR="$SCRIPT_DIR/venv"
if [ ! -d "$VENV_DIR" ]; then
    info "Criando ambiente virtual Python em $VENV_DIR..."
    python3 -m venv "$VENV_DIR"
    ok "Ambiente virtual criado."
else
    warn "Ambiente virtual já existe — pulando criação."
fi

PIP="$VENV_DIR/bin/pip"

info "Atualizando pip..."
"$PIP" install --upgrade pip -q

# ── Instalar dependências Python ────────────────────────────
info "[1/6] Instalando Flask..."
"$PIP" install flask -q && ok "Flask instalado."

info "[2/6] Instalando Flask-CORS..."
"$PIP" install flask-cors -q && ok "Flask-CORS instalado."

info "[3/6] Instalando pdf2docx (pode demorar 2-3 min)..."
"$PIP" install pdf2docx -q && ok "pdf2docx instalado."

info "[4/6] Instalando openpyxl..."
"$PIP" install openpyxl -q && ok "openpyxl instalado."

info "[5/6] Instalando pyxlsb..."
"$PIP" install pyxlsb -q && ok "pyxlsb instalado."

info "[6/6] Instalando opencv-python-headless e Pillow..."
"$PIP" install opencv-python-headless pillow pytesseract -q && ok "OpenCV, Pillow e pytesseract instalados."

# ── Criar pastas necessárias ────────────────────────────────
info "Criando pastas uploads/, outputs/ e logs/..."
mkdir -p "$SCRIPT_DIR/uploads" "$SCRIPT_DIR/outputs" "$SCRIPT_DIR/logs"
ok "Pastas criadas."

# ── Configurar permissões ───────────────────────────────────
# Descobrir usuário que executará o serviço (www-data para nginx, ou o usuário atual)
RUN_USER="${SUDO_USER:-www-data}"
info "Definindo dono dos arquivos: $RUN_USER..."
chown -R "$RUN_USER":"$RUN_USER" "$SCRIPT_DIR" 2>/dev/null || true
chmod +x "$SCRIPT_DIR/2_iniciar.sh" 2>/dev/null || true

# ── Verificar Tesseract ─────────────────────────────────────
if command -v tesseract &>/dev/null; then
    TESS_VER=$(tesseract --version 2>&1 | head -1)
    ok "Tesseract: $TESS_VER"
    TESS_LANGS=$(tesseract --list-langs 2>&1 | tail -n +2 | tr '\n' ' ')
    ok "Idiomas OCR disponíveis: $TESS_LANGS"
else
    warn "Tesseract não encontrado — OCR estará desabilitado."
fi

echo ""
echo "====================================================="
echo "  Instalação concluída!"
echo "====================================================="
echo ""
echo "Próximos passos:"
echo "  Iniciar manualmente:   bash 2_iniciar.sh"
echo "  Instalar como serviço: sudo bash 3_instalar_servico.sh"
echo "  Configurar Nginx:      sudo bash 4_configurar_nginx.sh"
echo ""
echo "Após iniciar, acesse: http://$(hostname -I | awk '{print $1}'):5000"
echo ""
