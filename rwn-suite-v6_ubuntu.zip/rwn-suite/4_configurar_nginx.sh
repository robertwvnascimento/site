#!/bin/bash
# =============================================================
#   RWN Document Suite v6 — Configurar Nginx como proxy reverso
#   Equivalente ao web.config do IIS
# =============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${BLUE}[INFO]${NC} $1"; }
ok()    { echo -e "${GREEN}[OK]${NC}   $1"; }
warn()  { echo -e "${YELLOW}[AVISO]${NC} $1"; }
erro()  { echo -e "${RED}[ERRO]${NC} $1"; exit 1; }

if [ "$EUID" -ne 0 ]; then
    erro "Execute como root: sudo bash 4_configurar_nginx.sh"
fi

# ── Perguntar domínio/IP ────────────────────────────────────
SERVER_IP=$(hostname -I | awk '{print $1}')
echo ""
echo "====================================================="
echo "  RWN Document Suite — Configurar Nginx"
echo "====================================================="
echo ""
echo "  IP detectado do servidor: $SERVER_IP"
echo ""
read -rp "  Domínio ou IP para o Nginx (ex: rwn.empresa.com ou $SERVER_IP): " SERVER_NAME
SERVER_NAME="${SERVER_NAME:-$SERVER_IP}"

NGINX_CONF="/etc/nginx/sites-available/rwn-document-suite"
NGINX_LINK="/etc/nginx/sites-enabled/rwn-document-suite"

info "Criando configuração Nginx em $NGINX_CONF..."

cat > "$NGINX_CONF" <<EOF
# =============================================================
#   RWN Document Suite — Nginx Reverse Proxy
#   Gerado automaticamente por 4_configurar_nginx.sh
# =============================================================

# Aumentar limite de upload para PDFs grandes (100MB)
client_max_body_size 100M;

server {
    listen 80;
    server_name $SERVER_NAME;

    # Logs
    access_log /var/log/nginx/rwn-access.log;
    error_log  /var/log/nginx/rwn-error.log;

    # Timeouts maiores para conversão de PDFs longos
    proxy_connect_timeout       600s;
    proxy_send_timeout          600s;
    proxy_read_timeout          600s;
    send_timeout                600s;

    # Proxy para Flask na porta 5000
    location / {
        proxy_pass         http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_set_header   Connection        "";

        # Buffering desabilitado para SSE/streaming de progresso
        proxy_buffering    off;
        proxy_cache        off;
    }

    # Cache de assets estáticos
    location /static/ {
        proxy_pass http://127.0.0.1:5000/static/;
        expires 7d;
        add_header Cache-Control "public, immutable";
    }
}
EOF

ok "Configuração criada."

# ── Ativar site ─────────────────────────────────────────────
if [ ! -f "$NGINX_LINK" ]; then
    info "Habilitando site no Nginx..."
    ln -s "$NGINX_CONF" "$NGINX_LINK"
    ok "Site habilitado."
else
    warn "Link simbólico já existe — atualizado."
    ln -sf "$NGINX_CONF" "$NGINX_LINK"
fi

# ── Remover default se existir ──────────────────────────────
if [ -f "/etc/nginx/sites-enabled/default" ]; then
    warn "Removendo site 'default' do Nginx para evitar conflito..."
    rm -f /etc/nginx/sites-enabled/default
fi

# ── Testar e recarregar ─────────────────────────────────────
info "Testando configuração Nginx..."
nginx -t

info "Recarregando Nginx..."
systemctl reload nginx || systemctl restart nginx

ok "Nginx configurado e recarregado."

echo ""
echo "====================================================="
echo "  Nginx configurado com sucesso!"
echo "====================================================="
echo ""
echo "  Acesse sem porta: http://$SERVER_NAME"
echo "  (O Flask continua disponível diretamente em :5000)"
echo ""
echo "  Para HTTPS com Let's Encrypt (opcional):"
echo "    apt install certbot python3-certbot-nginx"
echo "    certbot --nginx -d $SERVER_NAME"
echo ""
