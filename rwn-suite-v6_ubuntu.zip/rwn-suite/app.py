"""
RWN Document Suite - Backend Flask v6.0 (Ubuntu/Linux)
- Motor pdf2docx paralelo (lattice/stream/default por pagina)
- OCR hibrido: Tesseract + OpenCV deskew
- Pos-processamento: tabelas, fontes, shapes, espacos em negrito
- Controle de concorrencia: fila global limita jobs simultaneos
- Suporte a 50 usuarios: fila FIFO, feedback de posicao na fila
"""

import os, sys, uuid, copy, shutil, threading, time, logging, subprocess, multiprocessing
from concurrent.futures import ProcessPoolExecutor, as_completed
from flask import Flask, request, jsonify, send_file, render_template
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
OUTPUT_FOLDER = os.path.join(BASE_DIR, "outputs")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

PYTHON_EXECUTABLE = sys.executable

# Controle de concorrencia
MAX_CONCURRENT  = 2
_active_slots   = threading.Semaphore(MAX_CONCURRENT)
_queue_lock     = threading.Lock()
_queue_position = {}

JOBS: dict = {}

FONT_MAP = {
    "times": "Times New Roman", "timesnewroman": "Times New Roman",
    "georgia": "Georgia", "garamond": "Garamond",
    "palatino": "Palatino Linotype", "helvetica": "Arial",
    "calibri": "Calibri", "verdana": "Verdana",
    "trebuchet": "Trebuchet MS", "franklin": "Franklin Gothic Medium",
    "myriad": "Arial", "optima": "Segoe UI",
    "futura": "Century Gothic", "avenir": "Century Gothic",
    "frutiger": "Arial", "univers": "Arial",
    "trade gothic": "Arial Narrow", "officina": "Calibri",
    "minion": "Times New Roman", "courier": "Courier New",
    "lucida": "Lucida Console", "symbol": "Symbol",
    "wingdings": "Wingdings", "cmbx": "Times New Roman",
    "cmr": "Times New Roman", "cmtt": "Courier New",
}

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s",
                    handlers=[logging.StreamHandler(sys.stdout)])
log = logging.getLogger("rwn")


# Utilitarios

def try_import_pdf2docx():
    try:
        import pdf2docx
        try:
            version = pdf2docx.__version__
        except AttributeError:
            try:
                from importlib.metadata import version as pv
                version = pv("pdf2docx")
            except Exception:
                version = "instalado"
        return pdf2docx, version, None
    except ImportError as e:
        return None, None, str(e)

def _find_exe(candidates, cmd_fallback):
    for p in candidates:
        if os.path.isfile(p): return p, True
    try:
        r = subprocess.run([cmd_fallback, "--version"], capture_output=True, timeout=5)
        if r.returncode == 0: return cmd_fallback, True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None, False

def detect_tesseract():
    """Detecta Tesseract em Windows e Linux/Ubuntu."""
    return _find_exe([
        # Windows
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        r"C:\tesseract\tesseract.exe",
        # Linux
        "/usr/bin/tesseract",
        "/usr/local/bin/tesseract",
    ], "tesseract")

def detect_opencv():
    try:
        import cv2
        return True
    except ImportError:
        return False

def map_font_name(name: str) -> str:
    if not name: return "Calibri"
    key = name.lower().strip()
    for pattern, replacement in FONT_MAP.items():
        if pattern in key: return replacement
    return name

def cleanup_orphan_files():
    for folder in [UPLOAD_FOLDER, OUTPUT_FOLDER]:
        try:
            for fname in os.listdir(folder):
                fpath = os.path.join(folder, fname)
                if not os.path.isfile(fpath): continue
                is_temp = (("_b" in fname or "_p" in fname or "_ocr" in fname)
                           and fname.endswith((".docx", ".txt")))
                if is_temp or time.time() - os.path.getmtime(fpath) > 1800:
                    try: os.remove(fpath)
                    except Exception: pass
        except Exception: pass

threading.Thread(
    target=lambda: [time.sleep(300) or cleanup_orphan_files() for _ in iter(int, 1)],
    daemon=True
).start()


# Pre-analise

def analyze_page(page):
    blocks     = [b for b in page.get_text("blocks") if b[6] == 0]
    char_count = sum(len(b[4]) for b in blocks)
    images     = page.get_images(full=False)
    is_scanned = False
    if images and char_count < 50:
        for img in images:
            try:
                bbox = page.get_image_bbox(img[0])
                if abs(bbox.width * bbox.height) > page.rect.width * page.rect.height * 0.5:
                    is_scanned = True; break
            except Exception: pass
    drawings   = page.get_drawings()
    line_count = len([d for d in drawings if d.get("type") in ("l","r","s") and d.get("width",1) < 3])
    text_cols  = len(sorted(set(round(b[0]/30)*30 for b in blocks)))
    table_mode = "lattice" if line_count > 10 else ("stream" if text_cols >= 3 and line_count < 5 else "default")
    return {"has_text": bool(blocks), "is_scanned": is_scanned,
            "line_count": line_count, "text_cols": text_cols,
            "table_mode": table_mode, "char_count": char_count}

def analyze_pdf(pdf_path):
    import fitz
    doc = fitz.open(pdf_path)
    analyses, scanned = [], []
    counts = {"lattice": 0, "stream": 0, "default": 0}
    for i in range(len(doc)):
        a = analyze_page(doc[i])
        analyses.append(a); counts[a["table_mode"]] += 1
        if a["is_scanned"]: scanned.append(i)
    doc.close()
    return {"total_pages": len(analyses), "dominant_mode": max(counts, key=counts.get),
            "scanned_pages": scanned, "page_analyses": analyses, "mode_counts": counts}


# OCR

def ocr_page_to_text(page, tesseract_path=None, lang="por+eng"):
    import fitz, numpy as np
    pix       = page.get_pixmap(matrix=fitz.Matrix(300/72, 300/72), colorspace=fitz.csGRAY)
    img_bytes = pix.tobytes("png")
    try:
        import cv2
        arr    = np.frombuffer(img_bytes, dtype=np.uint8)
        gray   = cv2.imdecode(arr, cv2.IMREAD_GRAYSCALE)
        binimg = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                       cv2.THRESH_BINARY, 11, 2)
        coords = np.column_stack(np.where(255 - binimg > 0))
        if len(coords) > 100:
            angle = cv2.minAreaRect(coords)[-1]
            if angle < -45: angle = 90 + angle
            if abs(angle) > 0.5:
                h, w   = binimg.shape; center = (w//2, h//2)
                M      = cv2.getRotationMatrix2D(center, angle, 1.0)
                binimg = cv2.warpAffine(binimg, M, (w, h), flags=cv2.INTER_CUBIC,
                                        borderMode=cv2.BORDER_REPLICATE)
        _, buf = cv2.imencode(".png", binimg); img_bytes = buf.tobytes()
    except (ImportError, Exception): pass
    try:
        import pytesseract; from PIL import Image; import io
        if tesseract_path and tesseract_path != "tesseract":
            pytesseract.pytesseract.tesseract_cmd = tesseract_path
        return pytesseract.image_to_string(Image.open(io.BytesIO(img_bytes)), lang=lang).strip()
    except Exception: return ""


# Pos-processamento

def fix_tables_and_styles(docx_path, progress_cb=None):
    from docx import Document
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    def _rep(pct, msg):
        if progress_cb:
            try: progress_cb(pct, msg)
            except Exception: pass

    try:
        _rep(0, "Abrindo DOCX...")
        doc = Document(docx_path)
    except Exception as e:
        log.error(f"[FIX] {e}"); return False, str(e)

    tables_fixed = fonts_mapped = shapes_removed = spaces_fixed = 0
    _rep(5, f"Otimizando {len(doc.tables)} tabela(s)...")

    for table in doc.tables:
        tables_fixed += 1
        if tables_fixed % 50 == 0:
            _rep(int(5 + tables_fixed / max(len(doc.tables), 1) * 75),
                 f"Tabela {tables_fixed}/{len(doc.tables)}...")
        for row in table.rows:
            for cell in row.cells:
                tc   = cell._tc
                tcPr = tc.find(qn("w:tcPr")) or OxmlElement("w:tcPr")
                if tc.find(qn("w:tcPr")) is None: tc.insert(0, tcPr)
                for old in tcPr.findall(qn("w:tcBorders")): tcPr.remove(old)
                tcB = OxmlElement("w:tcBorders")
                for side in ["top","left","bottom","right","insideH","insideV"]:
                    b = OxmlElement(f"w:{side}")
                    b.set(qn("w:val"), "single"); b.set(qn("w:sz"), "4")
                    b.set(qn("w:space"), "0");   b.set(qn("w:color"), "000000")
                    tcB.append(b)
                tcPr.append(tcB)
                for shd in tcPr.findall(qn("w:shd")):
                    if shd.get(qn("w:fill"), "auto").upper() in ("AUTO","FFFFFF","NONE",""): tcPr.remove(shd)
                for para in cell.paragraphs:
                    pPr = para._p.find(qn("w:pPr")) or OxmlElement("w:pPr")
                    if para._p.find(qn("w:pPr")) is None: para._p.insert(0, pPr)
                    for sp in pPr.findall(qn("w:spacing")): pPr.remove(sp)
                    sp_el = OxmlElement("w:spacing")
                    sp_el.set(qn("w:before"), "40"); sp_el.set(qn("w:after"), "40")
                    pPr.append(sp_el)
                    for run in para.runs:
                        rPr = run._r.find(qn("w:rPr"))
                        if rPr is None: continue
                        for pos in rPr.findall(qn("w:position")):
                            try:
                                if abs(int(pos.get(qn("w:val"), "0"))) > 20: rPr.remove(pos)
                            except ValueError: pass
                        for tag in [qn("w:sz"), qn("w:szCs")]:
                            for sz in rPr.findall(tag):
                                try:
                                    if int(sz.get(qn("w:val"), "20")) < 12: sz.set(qn("w:val"), "12")
                                except ValueError: pass
                        for rF in rPr.findall(qn("w:rFonts")):
                            for attr in ["w:ascii","w:hAnsi","w:cs","w:eastAsia"]:
                                val = rF.get(qn(attr))
                                if val:
                                    m = map_font_name(val)
                                    if m != val: rF.set(qn(attr), m); fonts_mapped += 1
        tblPr = table._tbl.find(qn("w:tblPr")) or OxmlElement("w:tblPr")
        if table._tbl.find(qn("w:tblPr")) is None: table._tbl.insert(0, tblPr)
        for el in tblPr.findall(qn("w:tblW")): tblPr.remove(el)
        tW = OxmlElement("w:tblW"); tW.set(qn("w:w"), "5000"); tW.set(qn("w:type"), "pct")
        tblPr.append(tW)
        for jc in tblPr.findall(qn("w:jc")): tblPr.remove(jc)
        jc = OxmlElement("w:jc"); jc.set(qn("w:val"), "left"); tblPr.append(jc)

    _rep(82, "Removendo shapes residuais...")
    body = doc.element.body
    WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
    WW = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    for drw in list(body.iter(f"{{{WW}}}drawing")):
        try:
            ext = drw.find(f".//{{{WP}}}extent")
            if ext is not None and int(ext.get("cx",999999)) < 25400 and int(ext.get("cy",999999)) < 25400:
                p = drw.getparent()
                if p is not None: p.remove(drw); shapes_removed += 1
        except Exception: pass

    _rep(88, "Aplicando mapeamento de fontes...")
    for para in doc.paragraphs:
        for run in para.runs:
            rPr = run._r.find(qn("w:rPr"))
            if rPr is None: continue
            for rF in rPr.findall(qn("w:rFonts")):
                for attr in ["w:ascii","w:hAnsi","w:cs"]:
                    val = rF.get(qn(attr))
                    if val:
                        m = map_font_name(val)
                        if m != val: rF.set(qn(attr), m); fonts_mapped += 1

    _rep(92, "Corrigindo espacos em negrito...")
    W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

    def _rtxt(run):
        return "".join((t.text or "") for t in run._r.findall(f"{{{W_NS}}}t"))

    def _bold(run):
        rPr = run._r.find(qn("w:rPr"))
        return rPr is not None and (rPr.find(qn("w:b")) is not None or rPr.find(qn("w:bCs")) is not None)

    for para in doc.paragraphs:
        runs = para.runs
        for i in range(len(runs) - 1):
            ct, nt = _rtxt(runs[i]), _rtxt(runs[i+1])
            if not ct or not nt: continue
            if ct[-1] == " " or nt[0] == " ": continue
            if not ct[-1].isalnum() or not nt[0].isalnum(): continue
            if _bold(runs[i]) and _bold(runs[i+1]):
                ts = runs[i]._r.findall(f"{{{W_NS}}}t")
                if ts:
                    ts[-1].text = (ts[-1].text or "") + " "
                    ts[-1].set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
                    spaces_fixed += 1

    _rep(95, "Salvando DOCX...")
    doc.save(docx_path)
    log.info(f"[FIX] tabelas={tables_fixed} fontes={fonts_mapped} "
             f"shapes={shapes_removed} espacos_negrito={spaces_fixed}")
    _rep(100, "Concluido.")
    return True, None


# Worker de lote

def _build_settings(mode: str) -> dict:
    base = {"float_image_ignorable_gap": 5, "table_border_tolerance": 1.5, "min_border_clearance": 2.0}
    if mode == "lattice":
        base.update({"connected_border_tolerance": 0.5, "line_overlap_threshold": 0.9,
                     "line_break_width_ratio": 0.5,    "lines_left_aligned_threshold": 0.1})
    elif mode == "stream":
        base.update({"connected_border_tolerance": 1.5, "line_overlap_threshold": 0.5,
                     "line_break_width_ratio": 0.3,    "lines_left_aligned_threshold": 0.3})
    else:
        base.update({"connected_border_tolerance": 0.5, "line_overlap_threshold": 0.9,
                     "line_break_width_ratio": 0.5,    "lines_left_aligned_threshold": 0.1})
    log.info(f"[CONFIG] Modo {mode.upper()}")
    return base

def _convert_batch_worker(args):
    pdf_path, batch_docx, start, end, settings, progress_file = args
    import logging as _log, re
    pat = re.compile(r"\((\d+)/\d+\)\s+Page")
    class _PH(_log.Handler):
        def __init__(self, pf): super().__init__(); self.pf = pf; self.count = 0
        def emit(self, record):
            if pat.search(record.getMessage()):
                self.count += 1
                try: open(self.pf, "w").write(str(self.count))
                except Exception: pass
    h = _PH(progress_file)
    lg = _log.getLogger("pdf2docx")
    lg.addHandler(h)
    if lg.level == _log.NOTSET or lg.level > _log.INFO: lg.setLevel(_log.INFO)
    try:
        from pdf2docx import Converter
        cv = Converter(pdf_path)
        cv.convert(batch_docx, start=start, end=end, **settings)
        cv.close()
        return ((batch_docx, h.count, None)
                if os.path.exists(batch_docx) and os.path.getsize(batch_docx) > 0
                else (None, h.count, "Arquivo nao gerado"))
    except Exception as e:
        return None, h.count, str(e)
    finally:
        lg.removeHandler(h)


# Mesclagem

def _merge_docx_files(batch_paths, output_path, progress_cb=None):
    from docx import Document
    _rep = lambda p, m: progress_cb(p, m) if progress_cb else None
    if not batch_paths: return
    if len(batch_paths) == 1: shutil.copy(batch_paths[0], output_path); return
    base = Document(batch_paths[0])
    body = base.element.body
    for i, path in enumerate(batch_paths[1:], 2):
        _rep(int(5 + (i-1) / max(len(batch_paths)-1, 1) * 85), f"Mesclando {i}/{len(batch_paths)}...")
        sub = Document(path)
        for el in sub.element.body:
            if not el.tag.endswith("}sectPr"): body.append(copy.deepcopy(el))
    base.save(output_path)


# Motor principal

def _convert_with_best_settings(pdf_path, docx_path, job_id=None):

    def set_job(pct, msg, step=None):
        if job_id and job_id in JOBS:
            JOBS[job_id].update({"progress": pct, "message": msg,
                                 **({
                                     "step": step} if step else {})})
        log.info(f"[JOB {job_id[:8] if job_id else '---'}] {msg}")

    set_job(2, "Limpando temporarios...", "cleanup"); cleanup_orphan_files()

    set_job(4, "Analisando estrutura do PDF...", "analysis")
    try:
        analysis = analyze_pdf(pdf_path)
    except Exception as e:
        log.warning(f"[ANALYSIS] Falhou ({e})")
        analysis = {"total_pages": 0, "dominant_mode": "default",
                    "scanned_pages": [], "page_analyses": [], "mode_counts": {}}

    total_pages   = analysis["total_pages"]
    dominant_mode = analysis["dominant_mode"]
    scanned_pages = analysis["scanned_pages"]
    log.info(f"[ANALYSIS] {total_pages} pag | modo={dominant_mode} | "
             f"escaneadas={len(scanned_pages)}")

    ocr_docx_path = None
    if scanned_pages:
        tess_path, tess_ok = detect_tesseract()
        if tess_ok:
            set_job(8, f"OCR em {len(scanned_pages)} pagina(s)...", "ocr")
            try:
                import fitz
                from docx import Document as D
                from docx.shared import Pt, Cm
                ocr_docx_path = docx_path.replace(".docx", "_ocr.docx")
                ocr_doc = D()
                for sec in ocr_doc.sections:
                    sec.top_margin = sec.bottom_margin = Cm(2)
                    sec.left_margin = sec.right_margin = Cm(2.5)
                pdf_doc = fitz.open(pdf_path)
                for idx in scanned_pages:
                    text = ocr_page_to_text(pdf_doc[idx], tess_path)
                    for line in (text or "").split("\n"):
                        if line.strip():
                            p = ocr_doc.add_paragraph(line.strip())
                            for r in p.runs: r.font.size = Pt(10)
                    if idx != scanned_pages[-1]: ocr_doc.add_page_break()
                pdf_doc.close(); ocr_doc.save(ocr_docx_path)
            except Exception as e:
                log.error(f"[OCR] {e}"); ocr_docx_path = None
        else:
            log.warning("[OCR] Tesseract nao encontrado — instale: apt install tesseract-ocr tesseract-ocr-por")

    non_scanned = [i for i in range(total_pages) if i not in scanned_pages]
    if not non_scanned and scanned_pages:
        if ocr_docx_path and os.path.exists(ocr_docx_path):
            shutil.copy(ocr_docx_path, docx_path); os.remove(ocr_docx_path)
            set_job(93, "Otimizando..."); fix_tables_and_styles(docx_path); return
        raise RuntimeError("100% escaneado mas OCR nao produziu resultado.")

    SETTINGS  = _build_settings(dominant_mode)
    cpu_count = max(1, multiprocessing.cpu_count() - 1)
    n_workers = min(cpu_count, 8) if total_pages > 30 else 1
    set_job(12, f"Iniciando {n_workers} workers...", "parallel")

    pages_per_worker = max(10, -(-len(non_scanned) // n_workers))
    batches, prog_files = [], []
    for i in range(0, len(non_scanned), pages_per_worker):
        chunk = non_scanned[i:i + pages_per_worker]
        start, end = chunk[0], chunk[-1] + 1
        bd = docx_path.replace(".docx", f"_b{start:04d}.docx")
        pf = docx_path.replace(".docx", f"_p{start:04d}.txt")
        batches.append((pdf_path, bd, start, end, SETTINGS, pf))
        prog_files.append(pf)

    import time as _t
    def _read_done():
        total = 0
        for pf in prog_files:
            try: total += int(open(pf).read().strip() or 0)
            except Exception: pass
        return total

    batch_results, errors = {}, []
    t0 = _t.time()
    _stop = threading.Event()
    _prog = {"batches_done": 0, "last_pct": 12}
    wait_msgs = [f"Inicializando {n_workers} processos...",
                 f"Carregando PDF ({total_pages} pag)...", "Preparando..."]
    _wi = [0]

    def _monitor():
        while not _stop.is_set():
            elapsed    = _t.time() - t0
            pages_done = _read_done()
            if pages_done > 0 and total_pages > 0:
                pct  = min(int(12 + pages_done / total_pages * 75), 87)
                rate = pages_done / elapsed if elapsed > 0 else 0
                rem  = (total_pages - pages_done) / rate if rate > 0 else 0
                eta  = (f"~{int(rem/60)}min {int(rem%60)}s" if rem > 60
                        else f"~{int(rem)}s" if rem > 5 else "finalizando...")
                msg  = f"Pagina {pages_done}/{total_pages} - {eta}"
            elif _prog["batches_done"] > 0:
                pct = int(12 + _prog["batches_done"] / max(len(batches), 1) * 70)
                msg = f"Lote {_prog['batches_done']}/{len(batches)}..."
            else:
                pct = min(12, int(12 + elapsed * 0.2))
                msg = wait_msgs[_wi[0] % len(wait_msgs)]; _wi[0] += 1
            if pct > _prog["last_pct"]:
                _prog["last_pct"] = pct; set_job(pct, msg, "converting")
            _stop.wait(1.0)

    mon = threading.Thread(target=_monitor, daemon=True)
    mon.start()
    with ProcessPoolExecutor(max_workers=n_workers) as ex:
        fmap = {ex.submit(_convert_batch_worker, b): b for b in batches}
        for future in as_completed(fmap):
            _, _, start, end, _, _ = fmap[future]
            _prog["batches_done"] += 1
            try:
                path, done, err = future.result()
                if path:
                    batch_results[start] = path
                    log.info(f"[BATCH] pag {start+1}-{end} OK")
                else:
                    errors.append(f"{start}-{end}: {err}")
                    log.warning(f"[BATCH] {start}-{end} falhou: {err}")
            except Exception as e:
                errors.append(str(e)); log.error(f"[BATCH] excecao: {e}")
    _stop.set(); mon.join(timeout=2)
    for pf in prog_files:
        try: os.remove(pf)
        except Exception: pass

    if not batch_results:
        log.warning("[FALLBACK] lotes falharam — tentando sequencial")
        set_job(50, "Conversao sequencial...", "fallback")
        from pdf2docx import Converter
        cv = Converter(pdf_path); cv.convert(docx_path); cv.close()
        if not os.path.exists(docx_path) or os.path.getsize(docx_path) == 0:
            raise RuntimeError(f"Falhou em todos os modos. Erros: {errors}")
    else:
        set_job(88, f"Mesclando {len(batch_results)} lotes...", "merging")
        ordered = [batch_results[k] for k in sorted(batch_results)]
        if ocr_docx_path and os.path.exists(ocr_docx_path):
            ordered.append(ocr_docx_path)
        _merge_docx_files(ordered, docx_path,
                          progress_cb=lambda p, m: set_job(int(88 + p/100*5), m, "merging"))
        for p in ordered:
            try: os.remove(p)
            except Exception: pass

    if not os.path.exists(docx_path) or os.path.getsize(docx_path) == 0:
        raise RuntimeError("Arquivo final nao gerado")

    set_job(93, "Otimizando tabelas e estilos...", "postprocess")
    fix_tables_and_styles(docx_path,
                          progress_cb=lambda p, m: set_job(int(93 + p/100*6), m, "postprocess"))

    log.info(f"[DONE] {len(batch_results)}/{len(batches)} lotes | "
             f"OCR={len(scanned_pages)} pag | erros={len(errors)}")
    if errors: log.warning(f"[DONE] Erros ignorados: {errors}")


# Rotas Flask

@app.route("/")
def index(): return render_template("index.html")


@app.route("/api/health")
def health():
    mod, version, err = try_import_pdf2docx()
    _, tess_ok        = detect_tesseract()
    active = MAX_CONCURRENT - _active_slots._value
    resp = jsonify({
        "status": "ok", "pdf2docx": mod is not None,
        "pdf2docx_version": version or "nao instalado",
        "tesseract": tess_ok, "opencv": detect_opencv(),
        "python_version": sys.version.split()[0],
        "concurrent_jobs": {"active": active, "max": MAX_CONCURRENT,
                            "queue": max(0, len(JOBS) - active)},
        "error": err,
    })
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    resp.headers["Access-Control-Allow-Origin"] = "*"
    return resp


@app.route("/api/pdf-to-docx", methods=["POST"])
def pdf_to_docx():
    if "file" not in request.files:
        return jsonify({"error": "Nenhum arquivo enviado"}), 400
    file = request.files["file"]
    if not file.filename.lower().endswith(".pdf"):
        return jsonify({"error": "Apenas PDFs sao aceitos"}), 400
    mod, _, _ = try_import_pdf2docx()
    if not mod:
        return jsonify({"error": "pdf2docx nao instalado"}), 500

    job_id    = str(uuid.uuid4())
    pdf_path  = os.path.join(UPLOAD_FOLDER, f"{job_id}.pdf")
    docx_path = os.path.join(OUTPUT_FOLDER, f"{job_id}.docx")
    file.save(pdf_path)

    JOBS[job_id] = {
        "status": "queued", "progress": 0,
        "message": "Aguardando na fila...", "step": "queue",
        "error": None, "filename": os.path.splitext(file.filename)[0] + ".docx",
    }

    def run():
        with _queue_lock:
            pos = sum(1 for j in JOBS.values() if j["status"] == "queued")
            _queue_position[job_id] = pos

        while not _active_slots.acquire(blocking=False):
            with _queue_lock:
                queue_jobs = [jid for jid, j in JOBS.items() if j["status"] == "queued"]
                pos = queue_jobs.index(job_id) + 1 if job_id in queue_jobs else 1
            JOBS[job_id].update({
                "message": f"Aguardando na fila (posicao {pos} de {len(queue_jobs)})...",
                "step": "queue"
            })
            time.sleep(2)

        try:
            JOBS[job_id].update({"status": "processing", "step": "init"})
            _convert_with_best_settings(pdf_path, docx_path, job_id)
            JOBS[job_id].update({"status": "done", "progress": 100, "message": "Concluido"})
        except Exception as e:
            log.error(f"[JOB] {e}")
            JOBS[job_id].update({"status": "error", "error": str(e)})
        finally:
            _active_slots.release()
            _queue_position.pop(job_id, None)
            try: os.remove(pdf_path)
            except Exception: pass

    threading.Thread(target=run, daemon=True).start()
    return jsonify({"job_id": job_id, "filename": JOBS[job_id]["filename"]})


@app.route("/api/pdf-to-docx/status/<job_id>")
def job_status(job_id):
    job = JOBS.get(job_id)
    if not job: return jsonify({"error": "Job nao encontrado"}), 404
    resp = jsonify(job)
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.route("/api/pdf-to-docx/download/<job_id>")
def job_download(job_id):
    job = JOBS.get(job_id)
    if not job or job.get("status") != "done":
        return jsonify({"error": "Arquivo nao disponivel"}), 404
    docx_path = os.path.join(OUTPUT_FOLDER, f"{job_id}.docx")
    filename  = job.get("filename", "convertido.docx")
    if not os.path.exists(docx_path):
        return jsonify({"error": "Arquivo expirado — converta novamente"}), 404
    JOBS.pop(job_id, None)
    threading.Thread(
        target=lambda: [time.sleep(60), os.path.exists(docx_path) and os.remove(docx_path)],
        daemon=True
    ).start()
    return send_file(docx_path, as_attachment=True, download_name=filename,
                     mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


# Compressor de Excel

@app.route("/api/compress-excel", methods=["POST"])
def compress_excel():
    if "file" not in request.files:
        return jsonify({"error": "Nenhum arquivo enviado"}), 400
    file  = request.files["file"]
    fname = file.filename.lower()
    ext   = os.path.splitext(fname)[1]
    if ext not in (".xlsx", ".xlsm", ".xlsb"):
        return jsonify({"error": "Apenas arquivos .xlsx, .xlsm e .xlsb sao aceitos"}), 400

    job_id   = str(uuid.uuid4())
    file_in  = os.path.join(UPLOAD_FOLDER, f"{job_id}_in{ext}")
    file_out = os.path.join(OUTPUT_FOLDER, f"{job_id}_out{ext}")
    file.save(file_in)
    original_size = os.path.getsize(file_in)

    try:
        import zipfile, io
        from PIL import Image

        imgs_before = imgs_after = 0
        buf = io.BytesIO()
        with zipfile.ZipFile(file_in, 'r') as zin:
            with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zout:
                for item in zin.infolist():
                    data       = zin.read(item.filename)
                    name_lower = item.filename.lower()
                    if (name_lower.startswith('xl/media/') and
                            name_lower.endswith('.png') and len(data) > 4096):
                        try:
                            imgs_before += len(data)
                            img     = Image.open(io.BytesIO(data))
                            out_img = io.BytesIO()
                            img.save(out_img, format='PNG', optimize=True, compress_level=9)
                            compressed = out_img.getvalue()
                            data = compressed if len(compressed) < len(data) else data
                            imgs_after += len(data)
                        except Exception as img_err:
                            log.warning(f"[EXCEL] imagem {item.filename}: {img_err}")
                            imgs_after += len(data)
                    info_zip = zipfile.ZipInfo(item.filename)
                    info_zip.compress_type = zipfile.ZIP_DEFLATED
                    zout.writestr(info_zip, data)
        buf.seek(0)
        with open(file_out, 'wb') as f:
            f.write(buf.read())

        final_size  = os.path.getsize(file_out)
        saved_bytes = original_size - final_size
        saved_pct   = round(saved_bytes / original_size * 100, 1) if original_size > 0 else 0
        img_saved   = imgs_before - imgs_after if imgs_before > 0 else 0
        out_filename = os.path.splitext(file.filename)[0] + "_comprimido" + ext
        log.info(f"[EXCEL] {file.filename}: {original_size:,} -> {final_size:,} bytes ({saved_pct}%)")
        return jsonify({
            "job_id": job_id, "filename": out_filename,
            "original_size": original_size, "final_size": final_size,
            "saved_bytes": saved_bytes, "saved_pct": saved_pct,
            "was_xlsb": ext == ".xlsb",
        })
    except Exception as e:
        log.error(f"[EXCEL] Erro: {e}")
        try: os.remove(file_in)
        except Exception: pass
        return jsonify({"error": str(e)}), 500
    finally:
        try: os.remove(file_in)
        except Exception: pass
        def _cleanup_later():
            time.sleep(1800)
            try: os.remove(file_out)
            except Exception: pass
        threading.Thread(target=_cleanup_later, daemon=True).start()


@app.route("/api/compress-excel/download/<job_id>")
def compress_excel_download(job_id):
    if not job_id.replace("-", "").isalnum():
        return jsonify({"error": "ID invalido"}), 400
    file_out = None
    for _ext in (".xlsx", ".xlsm", ".xlsb"):
        candidate = os.path.join(OUTPUT_FOLDER, f"{job_id}_out{_ext}")
        if os.path.exists(candidate):
            file_out = candidate; break
    if not file_out:
        return jsonify({"error": "Arquivo expirado — comprima novamente"}), 404
    filename = request.args.get("filename", "comprimido" + os.path.splitext(file_out)[1])
    return send_file(file_out, as_attachment=True, download_name=filename,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# Inicializacao

if __name__ == "__main__":
    multiprocessing.freeze_support()
    mod, version, _ = try_import_pdf2docx()
    _, tess_ok      = detect_tesseract()
    cpus            = multiprocessing.cpu_count()
    print("=" * 60)
    print(f"  RWN Document Suite v6.0 (Ubuntu/Linux)")
    print(f"  Python      : {sys.version.split()[0]}")
    print(f"  pdf2docx    : {version or 'NAO INSTALADO'}")
    print(f"  Tesseract   : {'OK' if tess_ok else 'NAO ENCONTRADO'}")
    print(f"  OpenCV      : {'OK' if detect_opencv() else 'NAO INSTALADO'}")
    print(f"  CPUs        : {cpus} | workers/job: {min(cpus-1,8)}")
    print(f"  Jobs simult.: {MAX_CONCURRENT} (fila automatica)")
    print("=" * 60)
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
